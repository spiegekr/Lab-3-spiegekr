using System;
using Expedia;
using NUnit.Framework;

namespace ExpediaTest
{
	[TestFixture()]
	public class FlightTest
	{
		//TODO Task 7 items go here

        private readonly DateTime StartDate = new DateTime(2012, 12, 21);
        private readonly DateTime EndDate = new DateTime(2012, 12, 26);

        [Test()]
        public void TestThatFlightInitializes()
        {
            var target = new Flight(StartDate, EndDate, 100);
            Assert.IsNotNull(target);
        }

        [Test()]
        public void TestThatFlightHasCorrectMileage()
        {
            var target = new Flight(StartDate, EndDate, 1000000);
            Assert.AreEqual(1000000, target.Miles);
        }
  
  

        [Test()]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void TestThatFlightThrowsOnBadMiles()
        {
            new Flight(StartDate, EndDate, -5);
        }

        [Test()]
        [ExpectedException(typeof(InvalidOperationException))]
        public void TestThatFlightThrowsOnBadMiles()
        {
            new Flight(EndDate, StartDate, 5);
        }
	}
}
